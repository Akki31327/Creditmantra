(function ($) {
  "use strict";

  /*============= preloader js css =============*/
  var cites = [];
  cites[0] =
    "Having different types of credit can improve your score";
  cites[1] = "Errors on your credit report can unfairly drop your credit score";
  cites[2] = "Unpaid utility bills can also negatively impact your credit score";
  cites[3] = "Checking your own credit score doesn’t affect your credit";
  var cite = cites[Math.floor(Math.random() * cites.length)];
  $("#preloader p").text(cite);
  $("#preloader").addClass("loading");

  $(window).on("load", function () {
    setTimeout(function () {
      $("#preloader").fadeOut(500, function () {
        $("#preloader").removeClass("loading");
      });
    }, 500);
  });
})(jQuery);
